// Product data - EDIT THIS to change your products
const products = [
  {
    id: 1,
    name: "Classic Building Blocks",
    price: 19.99,
    description: "Colorful interlocking blocks for endless creativity.",
    emoji: "🧱"
  },
  {
    id: 2,
    name: "Wooden Block Set",
    price: 24.99,
    description: "Natural wood blocks perfect for stacking and building.",
    emoji: "🪵"
  },
  {
    id: 3,
    name: "Creative Art Blocks",
    price: 14.99,
    description: "Painted blocks for artistic projects and decoration.",
    emoji: "🎨"
  },
  {
    id: 4,
    name: "Mega Block Kit",
    price: 34.99,
    description: "Large set with 100+ pieces for bigger builds.",
    emoji: "🏗️"
  },
  {
    id: 5,
    name: "Puzzle Block Game",
    price: 12.99,
    description: "Fun puzzle blocks that challenge and entertain.",
    emoji: "🧩"
  },
  {
    id: 6,
    name: "Glow-in-the-Dark Blocks",
    price: 22.99,
    description: "Special blocks that glow after being in the light.",
    emoji: "✨"
  }
];

// Cart functions
function getCart() {
  return JSON.parse(localStorage.getItem('cart')) || [];
}

function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

function addToCart(productId) {
  const cart = getCart();
  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.quantity += 1;
  } else {
    const product = products.find(p => p.id === productId);
    cart.push({ ...product, quantity: 1 });
  }
  saveCart(cart);
  alert('Added to cart!');
}

function removeFromCart(productId) {
  let cart = getCart();
  cart = cart.filter(item => item.id !== productId);
  saveCart(cart);
  displayCart();
}

function updateCartCount() {
  const cart = getCart();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const countEls = document.querySelectorAll('#cart-count');
  countEls.forEach(el => el.textContent = count);
}

function displayProducts(productList, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = productList.map(product => `
    <div class="product-card">
      <div class="product-image">${product.emoji}</div>
      <div class="product-info">
        <h4>${product.name}</h4>
        <p>${product.description}</p>
        <div class="price">$${product.price.toFixed(2)}</div>
        <button class="btn add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
      </div>
    </div>
  `).join('');
}

function displayCart() {
  const cart = getCart();
  const container = document.getElementById('cart-items');
  const totalEl = document.getElementById('cart-total');
  const checkoutBtn = document.getElementById('checkout-btn');

  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = '<p>Your cart is empty.</p>';
    totalEl.innerHTML = '';
    if (checkoutBtn) checkoutBtn.style.display = 'none';
    return;
  }

  if (checkoutBtn) checkoutBtn.style.display = 'inline-block';

  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div>
        <strong>${item.name}</strong><br>
        $${item.price.toFixed(2)} × ${item.quantity}
      </div>
      <div>
        <strong>$${(item.price * item.quantity).toFixed(2)}</strong>
        <button onclick="removeFromCart(${item.id})" style="margin-left: 10px; background: #dc3545; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;">Remove</button>
      </div>
    </div>
  `).join('');

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  totalEl.innerHTML = `Total: $${total.toFixed(2)}`;
}

function displayOrderSummary() {
  const cart = getCart();
  const container = document.getElementById('order-summary');
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = '<p>No items in cart.</p>';
    return;
  }

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  container.innerHTML = `
    <h3>Order Summary</h3>
    ${cart.map(item => `<p>${item.name} × ${item.quantity} — $${(item.price * item.quantity).toFixed(2)}</p>`).join('')}
    <p><strong>Total: $${total.toFixed(2)}</strong></p>
  `;
}

// Initialize cart count on page load
document.addEventListener('DOMContentLoaded', updateCartCount);